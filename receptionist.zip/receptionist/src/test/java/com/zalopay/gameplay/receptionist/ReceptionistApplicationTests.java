package com.zalopay.gameplay.receptionist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceptionistApplicationTests {

	@Test
	void contextLoads() {
	}

}
